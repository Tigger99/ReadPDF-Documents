import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import internal.GlobalVariable as GlobalVariable
//Needed for Spy Web work-around//
import org.openqa.selenium.chrome.ChromeDriver as ChromeDriver
import org.openqa.selenium.chrome.ChromeOptions as ChromeOptions
import org.openqa.selenium.remote.DesiredCapabilities as DesiredCapabilities
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory

//How to use Spy Web work-around
//#########################################################################################
//See https://forum.katalon.com/discussion/4969/katalon-does-not-recognize-own-opened-chrome-as-active-browser
//SpyWeb work-around allows Active browser to be used while running test cases through Katalon
//System.setProperty path must be updated for new Katalon versions
//#########################################################################################

//Replace click "Open Browser" with the following:
'SOF: SpyWeb work-around'
//When updating Katalon versions copy chromedriver.exe from C:\Katalon Installations\Katalon_Studio_Windows_xx-x.x\configuration\resources\drivers\chromedriver_win32
//Set your required path for chromedriver.exe
System.setProperty('webdriver.chrome.driver', 'Z:\\tools\\chromedriver.exe')

ChromeOptions options = new ChromeOptions()
//Set your required path for Katalon-Recorder-(Selenium-IDE-for-Chrome)_v3.1.2.crx
options.addExtensions(new File('Z:\\tools\\Katalon-Recorder-(Selenium-IDE-for-Chrome)_v3.1.2.crx'))

DesiredCapabilities capabilities = new DesiredCapabilities()

capabilities.setCapability(ChromeOptions.CAPABILITY, options)

ChromeDriver driver = new ChromeDriver(capabilities)

'EOF: SpyWeb work-around'
DriverFactory.changeWebDriver(driver)